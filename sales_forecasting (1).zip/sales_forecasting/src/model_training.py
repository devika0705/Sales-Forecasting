import pandas as pd
import numpy as np
import os
import joblib
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from xgboost import XGBRegressor
from statsmodels.tsa.arima.model import ARIMA
import warnings

warnings.filterwarnings('ignore')

def preprocess_and_train():
    print("Loading data...")
    df = pd.read_csv('data/retail_sales.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    
    os.makedirs('models', exist_ok=True)
    
    # 1. Anomaly Detection
    print("Training Isolation Forest for Anomaly Detection...")
    iso_forest = IsolationForest(contamination=0.01, random_state=42)
    # Give it Sales, Profit, and Region/Product encoded to detect numeric anomalies based on context
    le_region = LabelEncoder()
    le_product = LabelEncoder()
    
    # We will use global encoders
    df['Region_Code'] = le_region.fit_transform(df['Region'])
    df['Product_Code'] = le_product.fit_transform(df['Product'])
    
    features_iso = ['Sales', 'Profit', 'Region_Code', 'Product_Code']
    df['Anomaly'] = iso_forest.fit_predict(df[features_iso])
    
    joblib.dump(iso_forest, 'models/isolation_forest.pkl')
    
    # Save encoders
    encoders = {'region': le_region, 'product': le_product}
    joblib.dump(encoders, 'models/encoders.pkl')
    
    print("Outliers detected:", (df['Anomaly'] == -1).sum())

    # 2. Setup Data for XGBoost & Linear Regression
    print("Engineering features for supervised models...")
    df['Year'] = df['Date'].dt.year
    df['Month'] = df['Date'].dt.month
    df['Day'] = df['Date'].dt.day
    df['DayOfWeek'] = df['Date'].dt.dayofweek
    df['DayOfYear'] = df['Date'].dt.dayofyear
    
    # Target is Sales. We use Time features + Region + Product to predict
    features = ['Year', 'Month', 'Day', 'DayOfWeek', 'DayOfYear', 'Region_Code', 'Product_Code']
    X = df[features]
    y = df['Sales']
    
    # Train-test split by time (last 90 days for testing)
    cutoff_date = df['Date'].max() - pd.Timedelta(days=90)
    train_mask = df['Date'] <= cutoff_date
    test_mask = df['Date'] > cutoff_date
    
    X_train, X_test = X[train_mask].copy(), X[test_mask].copy()
    y_train, y_test = y[train_mask].copy(), y[test_mask].copy()
    
    # Linear Regression
    print("Training Linear Regression...")
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    lr_preds = lr.predict(X_test)
    print(f"LR MAE: {mean_absolute_error(y_test, lr_preds):.2f}")
    joblib.dump(lr, 'models/linear_regression.pkl')
    
    # XGBoost
    print("Training XGBoost...")
    xgb = XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=5, random_state=42)
    xgb.fit(X_train, y_train)
    xgb_preds = xgb.predict(X_test)
    print(f"XGB MAE: {mean_absolute_error(y_test, xgb_preds):.2f}")
    joblib.dump(xgb, 'models/xgboost_model.pkl')
    
    # 3. ARIMA specific (Aggregate Total Sales per day)
    print("Training ARIMA on Total Daily Sales...")
    daily_sales = df.groupby('Date')['Sales'].sum().reset_index()
    daily_sales = daily_sales.set_index('Date')
    
    # Ensure daily freq for ARIMA
    daily_sales = daily_sales.asfreq('D')
    
    train_daily = daily_sales[daily_sales.index <= cutoff_date]
    test_daily = daily_sales[daily_sales.index > cutoff_date]
    
    # Fit ARIMA(order=(5,1,0)) as a generic baseline
    arima_model = ARIMA(train_daily['Sales'], order=(5, 1, 0))
    arima_result = arima_model.fit()
    
    # Predict
    arima_preds = arima_result.forecast(steps=len(test_daily))
    print(f"ARIMA MAE: {mean_absolute_error(test_daily['Sales'], arima_preds):.2f}")
    
    # Save ARIMA
    # statsmodels recommends using save method for Results objects
    arima_result.save('models/arima_model.pkl')
    
    print("Model training complete and saved.")

if __name__ == "__main__":
    preprocess_and_train()
