import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import joblib
import os
import datetime

# --- Set Page Config (Need to be first) ---
st.set_page_config(page_title="Sales Forecasting Dashboard", layout="wide", page_icon="📈")

# --- Custom CSS for aesthetic tweaks ---
st.markdown("""
<style>
.stMetric {
    background-color: #1E1E1E;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.3);
}
</style>
""", unsafe_allow_html=True)

# --- Load Data and Models ---
@st.cache_data
def load_data():
    if not os.path.exists("data/retail_sales.csv"):
        st.error("No data found! Please run generate_data.py first.")
        st.stop()
    df = pd.read_csv("data/retail_sales.csv")
    df['Date'] = pd.to_datetime(df['Date'])
    return df

@st.cache_resource
def load_models():
    try:
        iso_forest = joblib.load('models/isolation_forest.pkl')
        encoders = joblib.load('models/encoders.pkl')
        xgb_model = joblib.load('models/xgboost_model.pkl')
        # statsmodels arima has a different load wrapper, let's use joblib or not load if not needed
        # We will use statsmodels.tsa.arima.model.ARIMAResults.load
        # but to keep it simple, we focus on XGB prediction
        return iso_forest, encoders, xgb_model
    except Exception as e:
        st.error(f"Error loading models: {e}")
        return None, None, None

df = load_data()
iso_forest, encoders, xgb_model = load_models()

# --- Pre-run anomalies if models exist ---
if iso_forest and encoders and 'Anomaly' not in df.columns:
    try:
        df_temp = df.copy()
        df_temp['Region_Code'] = encoders['region'].transform(df_temp['Region'])
        df_temp['Product_Code'] = encoders['product'].transform(df_temp['Product'])
        df['Anomaly'] = iso_forest.predict(df_temp[['Sales', 'Profit', 'Region_Code', 'Product_Code']])
    except Exception as e:
        pass

# --- Sidebar ---
st.sidebar.title("Filters 🔍")
regions = st.sidebar.multiselect("Select Region", options=df['Region'].unique(), default=df['Region'].unique())
products = st.sidebar.multiselect("Select Product", options=df['Product'].unique(), default=df['Product'].unique())

min_date = df['Date'].min()
max_date = df['Date'].max()
date_range = st.sidebar.date_input("Select Date Range", value=(min_date, max_date), min_value=min_date, max_value=max_date)

if len(date_range) == 2:
    start_date, end_date = pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1])
else:
    start_date, end_date = min_date, max_date

# Filter the dataframe
mask = (df['Region'].isin(regions)) & (df['Product'].isin(products)) & (df['Date'] >= start_date) & (df['Date'] <= end_date)
filtered_df = df.loc[mask].copy()

# --- Main Dashboard ---
st.title("📊 Retail Sales & Forecasting Dashboard")
st.markdown("Monitor historical sales data, identify anomalies, and forecast future revenue.")

tab1, tab2 = st.tabs(["Overview & EDA", "Forecasting"])

with tab1:
    st.header("Business Overview")
    
    # KPIs
    st.markdown("### Key Metrics")
    col1, col2, col3, col4 = st.columns(4)
    total_sales = filtered_df['Sales'].sum()
    total_profit = filtered_df['Profit'].sum()
    avg_daily = filtered_df.groupby('Date')['Sales'].sum().mean()
    anomalies_count = (filtered_df['Anomaly'] == -1).sum() if 'Anomaly' in filtered_df.columns else 0
    
    col1.metric("Total Sales", f"${total_sales:,.0f}")
    col2.metric("Total Profit", f"${total_profit:,.0f}")
    col3.metric("Avg Daily Sales", f"${avg_daily:,.0f}")
    col4.metric("Anomalies Detected", f"{anomalies_count}", delta_color="inverse")
    
    # Time Series Plot
    st.markdown("### Sales Trend over Time")
    daily_sales = filtered_df.groupby('Date').agg({'Sales': 'sum', 'Profit': 'sum'}).reset_index()
    
    fig_line = px.line(daily_sales, x='Date', y='Sales', title="Daily Total Sales", template="plotly_dark", color_discrete_sequence=["#00B4D8"])
    fig_line.update_layout(hovermode="x unified")
    st.plotly_chart(fig_line, use_container_width=True)
    
    # Anomaly Plot
    if anomalies_count > 0:
        st.markdown("### Anomalies Highlights")
        anom_df = filtered_df[filtered_df['Anomaly'] == -1]
        fig_anom = px.scatter(filtered_df, x='Date', y='Sales', color=filtered_df['Anomaly'].astype(str),
                              color_discrete_map={'-1': 'red', '1': '#444'}, opacity=0.7,
                              title="Sales Anomalies (Isolation Forest)", template="plotly_dark")
        st.plotly_chart(fig_anom, use_container_width=True)
    
    # Breakdown Analysis
    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown("### Sales by Region")
        pie_region = px.pie(filtered_df, names="Region", values="Sales", hole=0.4, template="plotly_dark")
        st.plotly_chart(pie_region, use_container_width=True)
    
    with col_b:
        st.markdown("### Sales by Product")
        bar_product = px.bar(filtered_df.groupby('Product')['Sales'].sum().reset_index().sort_values('Sales'), 
                             x="Sales", y="Product", orientation='h', color="Product", template="plotly_dark")
        st.plotly_chart(bar_product, use_container_width=True)

with tab2:
    st.header("Future Projections (XGBoost)")
    st.markdown("Generate synthetic predictions for the specified number of days into the future based on historical features.")
    
    forecast_days = st.slider("Forecast Horizon (Days)", min_value=7, max_value=90, value=30, step=7)
    
    if st.button("Generate Forecast", type="primary"):
        if not xgb_model or not encoders:
            st.error("Models not found!")
        else:
            with st.spinner(f"Forecasting {forecast_days} days..."):
                # Create future dates
                future_dates = pd.date_range(start=max_date + pd.Timedelta(days=1), periods=forecast_days, freq='D')
                
                # We need to create the same features for all Region-Product combinations selected
                future_records = []
                for d in future_dates:
                    for r in regions:
                        for p in products:
                            future_records.append({
                                'Date': d,
                                'Region': r,
                                'Product': p,
                                'Year': d.year,
                                'Month': d.month,
                                'Day': d.day,
                                'DayOfWeek': d.dayofweek,
                                'DayOfYear': d.dayofyear,
                                'Region_Code': encoders['region'].transform([r])[0],
                                'Product_Code': encoders['product'].transform([p])[0]
                            })
                            
                future_df = pd.DataFrame(future_records)
                
                # Predict
                features = ['Year', 'Month', 'Day', 'DayOfWeek', 'DayOfYear', 'Region_Code', 'Product_Code']
                future_df['Predicted_Sales'] = xgb_model.predict(future_df[features])
                
                # Aggregate for plotting
                agg_future = future_df.groupby('Date')['Predicted_Sales'].sum().reset_index()
                
                # Historical
                hist_agg = daily_sales[daily_sales['Date'] >= max_date - pd.Timedelta(days=90)]
                hist_agg.rename(columns={'Sales': 'Value'}, inplace=True)
                hist_agg['Type'] = 'Historical'
                
                agg_future.rename(columns={'Predicted_Sales': 'Value'}, inplace=True)
                agg_future['Type'] = 'Forecast'
                
                # Combine
                plot_df = pd.concat([hist_agg[['Date', 'Value', 'Type']], agg_future[['Date', 'Value', 'Type']]])
                
                fig_predict = px.line(plot_df, x='Date', y='Value', color='Type', 
                                      color_discrete_map={'Historical': '#BBD0FF', 'Forecast': '#FF9F1C'},
                                      title=f"Sales Forecast (Next {forecast_days} Days)",
                                      template="plotly_dark")
                
                fig_predict.add_vline(x=max_date.timestamp() * 1000, line_dash="dash", line_color="gray", annotation_text="Forecast Start")
                st.plotly_chart(fig_predict, use_container_width=True)
                
                st.markdown("### Daily Forecast Data")
                st.dataframe(agg_future, use_container_width=True)
