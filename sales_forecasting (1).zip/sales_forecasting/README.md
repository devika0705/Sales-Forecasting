# Sales Forecasting Dashboard

An end-to-end Machine Learning project to forecast retail sales, with Anomaly Detection and an interactive Streamlit Dashboard.

## Features
- **Data Generation**: Generates 3 years of synthetic retail data with seasonal trends and injected anomalies.
- **Anomaly Detection**: Uses IsolationForest (`sklearn`) to flag unusual sales spikes or drops.
- **Predictive Modeling**: Trains XGBoost and ARIMA (`statsmodels`) to forecast future daily sales.
- **Interactive Dashboard**: Modern Streamlit frontend to interactively explore historical data and visualize predictions up to 90 days in the future.

## Tech Stack
- Python 3.10
- Scikit-Learn
- XGBoost
- Statsmodels
- Streamlit
- Plotly

## Local Setup & Execution

**1. Install Dependencies**

Make sure you are in the project root:
```bash
pip install -r requirements.txt
```

**2. Generate Data**

Run the synthetic data generation script first to create `.csv` data in the `data/` directory.
```bash
python generate_data.py
```

**3. Train Models**

Run the training pipeline. This will train IsolationForest, Linear Regression, XGBoost, and ARIMA. It saves the results to the `models/` directory.
```bash
python src/model_training.py
```

**4. Launch the Dashboard**

Start Streamlit. It will open up a local web server (typically `http://localhost:8501`).
```bash
streamlit run app.py
```

## Dashboard Usage
- Use the **Sidebar Filters** to select Date Ranges, Regions, and Products. 
- In the **Overview & EDA tab**, review the high-level KPI cards and analyze historical data, including anomaly plots and regional breakdowns.
- In the **Forecasting tab**, use the slider to choose the forecast horizon and click "Generate Forecast" to have the underlying XGBoost model predict the upcoming dates using extrapolated temporal features.

## Deployment
To deploy this on **Streamlit Cloud**:
1. Commit this entire directory to a GitHub repository.
2. Sign in to Streamlit Community Cloud (share.streamlit.io).
3. Connect your GitHub account and select this repository.
4. Set the main file path to `app.py`.
5. Click **Deploy!**
