import pandas as pd
import numpy as np
import os

def generate_synthetic_sales_data(filepath='data/retail_sales.csv', start_date='2021-01-01', end_date='2023-12-31'):
    print("Generating synthetic retail sales data...")
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    regions = ['North', 'South', 'East', 'West']
    products = ['Electronics', 'Clothing', 'Furniture', 'Groceries']
    
    # Base configuration for products (base sales and profit margin)
    product_config = {
        'Electronics': {'base': 1500, 'margin': 0.20, 'volatility': 0.3},
        'Clothing': {'base': 800, 'margin': 0.40, 'volatility': 0.2},
        'Furniture': {'base': 1200, 'margin': 0.25, 'volatility': 0.4},
        'Groceries': {'base': 500, 'margin': 0.15, 'volatility': 0.1}
    }
    
    # Base config for regions
    region_multiplier = {
        'North': 1.2,
        'South': 0.9,
        'East': 1.1,
        'West': 1.0
    }
    
    records = []
    
    # Pre-calculate time components
    days_from_start = (dates - dates[0]).days.values
    dayofyear = dates.dayofyear.values
    month = dates.month.values
    year = dates.year.values
    
    # Global trend: e.g., 0.05% growth per day
    trend = 1 + (days_from_start * 0.0003)
    
    # Seasonality (Yearly)
    # Peak around November/December (holiday season)
    seasonality = 1 + 0.3 * np.sin(2 * np.pi * (dayofyear - 300) / 365) + 0.1 * np.cos(2 * np.pi * (dayofyear - 150) / 365)

    np.random.seed(42)
    
    for r in regions:
        for p in products:
            base = product_config[p]['base'] * region_multiplier[r]
            volatility = product_config[p]['volatility']
            
            # Additional noise
            noise = np.random.normal(0, volatility, len(dates))
            
            # Combine components
            daily_sales = base * trend * seasonality * (1 + noise)
            
            # Ensure no negative sales
            daily_sales = np.maximum(daily_sales, 50)
            
            # Calculate profit
            profit_margin = product_config[p]['margin']
            # Introduce slight variance to profit
            profit = daily_sales * (profit_margin + np.random.normal(0, 0.05, len(dates)))
            
            # Inject Anomalies (spikes or drops)
            num_anomalies = int(len(dates) * 0.01) # 1% anomalies
            anomaly_indices = np.random.choice(len(dates), num_anomalies, replace=False)
            
            for idx in anomaly_indices:
                spike_factor = np.random.choice([0.2, 0.3, 2.5, 3.0, 4.0]) # either steep drop or big spike
                daily_sales[idx] *= spike_factor
                profit[idx] = daily_sales[idx] * profit_margin
                
            df_temp = pd.DataFrame({
                'Date': dates,
                'Region': r,
                'Product': p,
                'Sales': np.round(daily_sales, 2),
                'Profit': np.round(profit, 2)
            })
            records.append(df_temp)

    final_df = pd.concat(records, ignore_index=True)
    
    # Create data dir if not exists
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    final_df.to_csv(filepath, index=False)
    print(f"Data generation complete! Saved {len(final_df)} records to {filepath}")

if __name__ == "__main__":
    generate_synthetic_sales_data('data/retail_sales.csv')
